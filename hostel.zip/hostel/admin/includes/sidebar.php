<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label"><center>Main</center></li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i><b> Dashboard</b></a></li>
					<li><a href="#"><i class="fa fa-files-o"></i><b> Courses</b></a>
					<ul>
						<li><a href="add-courses.php">Add Courses</a></li>
						<li><a href="manage-courses.php">Manage Courses</a></li>
					</ul>
				</li>
					<li><a href="#"><i class="fa fa-desktop"></i><b> Rooms</b></a>
					<ul>
						<li><a href="create-room.php">Add a Room</a></li>
						<li><a href="manage-rooms.php">Manage Rooms</a></li>
					</ul>
				</li>

				<li><a href="registration.php"><i class="fa fa-user"></i><b>Student Registration</b></a></li>
				<li><a href="manage-students.php"><i class="fa fa-users"></i><b>Manage Students</b></a></li>
				<li><a href="access-log.php"><i class="fa fa-file"></i><b>User Access logs</b></a></li>

			
		</nav>