


<?php
session_start();
if(!$_SESSION["login_user"])
{
	header("location:http://localhost/NIT%20Exchange%20Store%20(NES)/login.php?notlogin= sorry! you are not loged in");
}
include 'php/manish_db.php';
if(isset($_POST['purchase']))
{
	$goods_user_name=$_POST["user_name"];
	$login_user=$_SESSION['login_user'];
	$product_id=$_POST['id'];
	require 'php/PHPMailer/PHPMailerAutoload.php';
	$sql3="select * from  purchased where user_name='$login_user' and id=$product_id";
		$result3=mysqli_query($con,$sql3);
		if($result3)
	if(mysqli_num_rows($result3)>0)
		echo "you already purchased this item please choose another";
	else
	{
				$sql0="insert into purchased (id,user_name) values($product_id,'$login_user')";
				$result0=mysqli_query($con,$sql0);
				if($result0){
					$sql="select * from user where user_name='$login_user'";
					$sql1="select * from user where user_name='$goods_user_name'";
					$result=mysqli_query($con,$sql);
					$result1=mysqli_query($con,$sql1);
					$row=mysqli_fetch_array($result);
					$row1=mysqli_fetch_array($result1);
					if($row && $row1)
					{
						$login_user_email=$row[4];
						$goods_user_email=$row1[4];			
						//echo $login_user_email;
						//echo $goods_user_email;
						$login_user_first_name=$row[1];
						$login_user_last_name=$row[2];
						$login_user_mobile_number=$row[7];
						$login_user_address=$row[9];
						$goods_user_first_name=$row1[1];
						$goods_user_last_name=$row1[2];
						$mail=new PHPMailer();
							$mail->isSmtp();
							$mail->SMTPDebug=0;
							$mail->SMTPAuth=true;
							$mail->SMTPSecure='ssl';
							$mail->Host="smtp.gmail.com";
							$mail->Port=465;//587
							$mail->isHTML(true);
							$mail->Username="dndapply@gmail.com";
							$mail->Password="dnddnd@123";
							$mail->SetFrom("dndapply@gmail.com");
							$mail->Subject="National Institute of Technology Calicut (kerala) Exchange Store";
							$mail->Body="hello Mr. ".$login_user_first_name. " your response is important for me. you will be contacted soon. thanks! - ";
							$mail->AddAddress($login_user_email);
							if($mail->Send())
								$i=1;

							$mail1=new PHPMailer();
							$mail1->isSmtp();
							$mail1->SMTPDebug=0;
							$mail1->SMTPAuth=true;
							$mail1->SMTPSecure='ssl';
							$mail1->Host="smtp.gmail.com";
							$mail1->Port=465;//587
							$mail1->isHTML(true);
							$mail1->Username="dndapply@gmail.com";
							$mail1->Password="dnddnd@123";
							$mail1->SetFrom("dndapply@gmail.com");
							$mail1->Subject="National Institute of Technology Calicut (kerala) Exchange Store";
							$mail1->Body="hello Mr. ".$goods_user_first_name. " your product want to buy Mr. ".$login_user_first_name. " his  mobile no.-> ".$login_user_mobile_number." and address:- ".$login_user_address. "  so please contact him soon";
							$mail1->AddAddress($goods_user_email);
							if($mail1->Send())
							{
								$i=$i+1;
							}
							if($i==2){
								?>
								<div> <center><h1> Thanks for responding. </h1>
												<h3> please keep switch on you mobile or you can check email.</h3>
												<h3> you will be contacted soon.</h3>
												<h2> Thanks.</h2></center></div>
								<?php
							}
							else
								echo "somthing error please try again";
							
					}
				}

			else
				echo "somthing error please try again";

	}
}
?>



