<?php
$con=mysqli_connect('localhost','root',"","hostel") or die(mysql_error($con));
?>