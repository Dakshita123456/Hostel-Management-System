<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label"><br><br><br><center>MAIN MENU</center><br></li>
				<?php if(isset($_SESSION['id']))
				{ ?>
					<li><a href="dashboard.php"><i class="fa fa-desktop"></i><b>Dashboard</b></a></li>
					<li><a href="my-profile.php"><i class="fa fa-user"></i> <b>My Profile</b></a></li>
<li><a href="change-password.php"><i class="fa fa-files-o"></i><b>Change Password</b></a></li>
<li><a href="book-hostel.php"><i class="fa fa-file-o"></i><b>Book Hostel</b></a></li>
<li><a href="room-details.php"><i class="fa fa-file-o"></i><b>Room Details</b></a></li>
<li><a href="access-log.php"><i class="fa fa-file-o"></i><b>Access log</b></a></li>
<?php } else { ?>
				
				<li><a href="registration.php"><i class="fa fa-files-o"></i> <b>User Registration</b></a></li>
				<li><a href="login.php"><i class="fa fa-users"></i> <b>User Login</b></a></li>
				<li><a href="admin"><i class="fa fa-user"></i> <b>Admin Login</b></a></li>
				<?php } ?>

			</ul>
		</nav>