<?php
session_start();
include('includes/config.php');
if(isset($_POST['login']))
{
$email=$_POST['email'];
$password=$_POST['password'];
$stmt=$mysqli->prepare("SELECT email,password,id FROM userregistration WHERE email=? and password=? ");
				$stmt->bind_param('ss',$email,$password);
				$stmt->execute();
				$stmt -> bind_result($email,$password,$id);
				$rs=$stmt->fetch();
				$stmt->close();
				$_SESSION['id']=$id;
				$_SESSION['login']=$email;
				$uip=$_SERVER['REMOTE_ADDR'];
				$ldate=date('d/m/Y h:i:s', time());
				if($rs)
				{
             $uid=$_SESSION['id'];
             $uemail=$_SESSION['login'];
$ip=$_SERVER['REMOTE_ADDR'];
$geopluginURL='http://www.geoplugin.net/php.gp?ip='.$ip;
$addrDetailsArr = unserialize(file_get_contents($geopluginURL));
$city = $addrDetailsArr['geoplugin_city'];
$country = $addrDetailsArr['geoplugin_countryName'];
$log="insert into userLog(userId,userEmail,userIp,city,country) values('$uid','$uemail','$ip','$city','$country')";
$mysqli->query($log);
if($log)
{
header("location:dashboard.php");
				}
}
				else
				{
					echo "<script>alert('Invalid Username/Email or password');</script>";
				}
			}
?>



<html>
<head>
	<title>Welcome To NITC Hostel Registration Portal</title>
	<link rel="stylesheet" href="styles/style1.css">
	<link rel="shortcut icon" type="image/x-icon" href="images\nitl.png"></link>
</head>

<body>
	<div id="header">
		
		<div id="logo">
			<img src="images\logo.jpg" class="p1">
		</div>
		<div class="nav1">
			<ul>
			  <li><a class="active" href="index.php"><b>Home</b></a></li>
			  <li><a href="home.php"><b>Rooms</b></a></li>
			  <li><a href="#contact"><b>Contact</b></a></li>
			  <li style="float:right"><a href="#about"><b>About</b></a></li>
			</ul>
		
		</div>
		<div class="nav2">
			<ul>
			  <li><a href="registration.php"><b>Register</b></a></li>
			 
			  <li class="dropdown">
					<a href="javascript:void(0)" class="dropbtn"><b>Login</b></a>
					<div class="dropdown-content">
					<a href="admin">ADMIN</a>
					<a href="login.php">STUDENT</a>
					
			 
			</ul>
		
		</div>
		
	</div>
	
	<div>-->content
		<div>-->slideshow
			<div>--->previous
			</div>
			<div>--->next
			</div>
		</div>
		
		<div>-->login
		
		</div>
	
	
	
	
	</div>--content close
	
	<div>-->footer
	
	</div>

</body>

</html>