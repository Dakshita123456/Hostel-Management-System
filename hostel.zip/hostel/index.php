<?php
session_start();
include('includes/config.php');
if(isset($_POST['login']))
{
$email=$_POST['email'];
$password=$_POST['password'];
$stmt=$mysqli->prepare("SELECT email,password,id FROM userregistration WHERE email=? and password=? ");
				$stmt->bind_param('ss',$email,$password);
				$stmt->execute();
				$stmt -> bind_result($email,$password,$id);
				$rs=$stmt->fetch();
				$stmt->close();
				$_SESSION['id']=$id;
				$_SESSION['login']=$email;
				$uip=$_SERVER['REMOTE_ADDR'];
				$ldate=date('d/m/Y h:i:s', time());
				if($rs)
				{
             $uid=$_SESSION['id'];
             $uemail=$_SESSION['login'];
$ip=$_SERVER['REMOTE_ADDR'];
$geopluginURL='http://www.geoplugin.net/php.gp?ip='.$ip;
$addrDetailsArr = unserialize(file_get_contents($geopluginURL));
$city = $addrDetailsArr['geoplugin_city'];
$country = $addrDetailsArr['geoplugin_countryName'];
$log="insert into userLog(userId,userEmail,userIp,city,country) values('$uid','$uemail','$ip','$city','$country')";
$mysqli->query($log);
if($log)
{
header("location:dashboard.php");
				}
}
				else
				{
					echo "<script>alert('Invalid Username/Email or password');</script>";
				}
			}
?>



<html>
<head>

	<title>Welcome To NITC Hostel Registration Portal</title>
	<link rel="stylesheet" href="styles/style1.css">
	<link rel="stylesheet" href="styles/style2.css">
	<link rel="shortcut icon" type="image/x-icon" href="images\nitl.png"></link>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

	
	<div id="slsh">
			<div class="w3-content w3-display-container ">
				  <img class="mySlides w3-animate-right" src="images\as1.jpg" style="width:100%">
				  <img class="mySlides w3-animate-left" src="images\as2.jpg" style="width:100%">
				  <img class="mySlides w3-animate-right" src="images\as3.jpg" style="width:100%">
				  <img class="mySlides w3-animate-left" src="images\as4.jpg" style="width:100%">
				  <img class="mySlides w3-animate-right" src="images\as5.jpg" style="width:100%">
				  <img class="mySlides w3-animate-left" src="images\as6.jpg" style="width:100%">
				 

				  <button class="w3-button w3-black w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
				  <button class="w3-button w3-black w3-display-right" onclick="plusDivs(1)">&#10095;</button>
			</div>
					<script>
						var slideIndex = 1;
						showDivs(slideIndex);

						function plusDivs(n) {
						  showDivs(slideIndex += n);
						}

						function showDivs(n) {
						  var i;
						  var x = document.getElementsByClassName("mySlides");
						  if (n > x.length) {slideIndex = 1}    
						  if (n < 1) {slideIndex = x.length}
						  for (i = 0; i < x.length; i++) {
							 x[i].style.display = "none";  
						  }
						  x[slideIndex-1].style.display = "block";  
						}
					
					
					
					</script>
					

		
		</div>


<div id="content">
	<div id="mpage">
		<div class="images">
			<img class="image" src="images\as1.jpg">
			<img class="image" src="images\as2.jpg">
			<img class="image" src="images\as3.jpg">
			<img class="image" src="images\as4.jpg">
			<img class="image" src="images\as5.jpg">
			<img class="image" src="images\as6.jpg">
		</div>
		<div id="fiction">
			<table>
				<tr>
					<th>
						<center>NEWS AND EVENTS<center>
					</th>
				</tr>
				<tr>
					<td><a href="registration.php"><font color="black" size="2px">Register for your new room</a></td>
				</tr>
				<tr>
					<td><a href="registration.php"><font color="black" size="2px">Register for your new room</a></td>
				</tr>
				<tr>
					<td><a href="registration.php"><font color="black" size="2px">Register for your new room</a></td>
				</tr>
			</table>
		</div>
		
			<div id="menu">
			<table>
				<tr>
					<th>
						<center>MENU<center>
					</th>
				</tr>
				<tr>
					<td><a href="registration.php"><font size="2px" >Register for your new room</a></td>
				</tr>
				<tr>
					<td><a href="registration.php"><font size="2px">Register for your new room</a></td>
				</tr>
				<tr>
					<td><a href="registration.php"><font  size="2px">Register for your new room</a></td>
				</tr>
			</table>
		</div>
	
		
		
</div>
	<script>
					(function() {
				  var cssTransition, imageOffset, imageWidth, images, queue, timeout, touch;

				  cssTransition = function() {
					var body, i, len, style, vendor, vendors;
					body = document.body || document.documentElement;
					style = body.style;
					vendors = ['Moz', 'Webkit', 'O'];
					if (typeof style['transition'] === 'string') {
					  return true;
					}
					for (i = 0, len = vendors.length; i < len; i++) {if (window.CP.shouldStopExecution(1)){break;}
					  vendor = vendors[i];
					  if (typeof style[vendor + 'Transition'] === 'string') {
						return true;
					  }
					}
				window.CP.exitedLoop(1);

					return false;
				  };

				  queue = false;

				  touch = document.documentElement['ontouchstart'] !== void 0;

				  images = document.querySelector('.images');

				  imageWidth = images.firstElementChild.offsetWidth;

				  imageOffset = images.firstElementChild.offsetLeft;

				  timeout = cssTransition() ? [300, 400] : [0, 0];

				  images.addEventListener((touch ? 'touchend' : 'click'), function(event) {
					var direction, lastClassList;
					if (queue) {
					  return;
					}
					queue = true;
					if (((touch ? event.changedTouches[0].pageX : event.pageX) - imageOffset) > imageWidth / 2) {
					  direction = 'slide-right';
					} else {
					  direction = 'slide-left';
					}
					lastClassList = images.lastElementChild.classList;
					lastClassList.add(direction);
					return setTimeout(function() {
					  lastClassList.remove(direction);
					  lastClassList.add('back');
					  return setTimeout(function() {
						images.insertBefore(images.lastElementChild, images.firstElementChild);
						lastClassList.remove('back');
						return queue = false;
					  }, timeout[0]);
					}, timeout[1]);
				  }, false);

				}).call(this);
	</script>

	
</div>
<div id="footer">
	<div id="footc">
			
			
			<table>
				<br>
					<tr>
						<th>ACADEMICS</th>
						<th>XYZasdf</th>
						<th>ABCAWSDDwf</th>
						<th>pqreEEEEE</th>
					</tr>
					<tr>
						<td><font size="2px">Peter</font></td>
						<td><font size="2px">Griffin</font></td>
						<td><font size="2px">$100</font></td>
						<td><font size="2px">$100</font></td>
					</tr>
					<tr>
						<td><font size="2px">Lois</font></td>
						<td><font size="2px">Griffin</font></td>
						<td><font size="2px">$150</font></td>
						<td><font size="2px">$100</td>
					</tr>
					<tr>
						<td><font size="2px"></font></td>
						<td><font size="2px">Swanson</font></td>
						<td><font size="2px">$100</font></td>
						<td><font size="2px">$300</font></td>
					</tr>
					<tr>
						<td><font size="2px"></font></td>
						<td><font size="2px">$100</font></td>
						<td><font size="2px">Brown</font></td>
						<td><font size="2px"></font></td>
					</tr>
									
									
									
			</table>
			
			
	</div>
	
</div>

<div id="header">
		
		<div id="logo">
			<img src="images\logo.jpg" class="p1">
		</div>
		<div id="nav1">
			<a href="index.php"><b>HOME</b></a> &nbsp &nbsp &nbsp <a href="home.php"><b>HOSTEL</b></a> &nbsp &nbsp &nbsp <a href="about.html"><b>ABOUT</b></a> &nbsp &nbsp &nbsp <a href="contact.html"><b>CONTACT</b></a>
		</div>
		
		<div id="nav2">
			<ul>
				  <li><a href="registration.php" class="active"><b>REGISTER</b></a></li>
				  
				  <li class="dropdown">
					<a href="javascript:void(0)" class="dropbtn"><b>LOGIN</b></a>
					<div class="dropdown-content">
					  <a href="admin">Admin</a>
					  <a href="login.php">Student</a>
					  
					</div>
				  </li>
			</ul>
		
		</div>
		
</div>
</body>
</html>


