<?php
require 'PHPMailer/PHPMailerAutoload.php';
$email1="dakshitasharma01995@gmail.com";
							$mail1=new PHPMailer();
							$mail1->isSmtp();
							$mail1->SMTPDebug=0;
							$mail1->SMTPAuth=true;
							$mail1->SMTPSecure='ssl';
							$mail1->Host="smtp.gmail.com";
							$mail1->Port=465;//587
							$mail1->isHTML(true);
							$mail1->Username="dndapply@gmail.com";
							$mail1->Password="dnddnd@123";
							$mail1->SetFrom("dndapply@gmail.com");
							$mail1->Subject="National Institute of Technology Calicut (kerala) ROOM ALLOATMENT";
							$mail1->Body="hello miss ds";
							$mail1->AddAddress($email1);
							if($mail1->Send())
							{
								?>
								<div> <center><h1> Thanks for Booking</h1>
												<h3> you can check your email for confermation.</h3>									
												<h2> Thanks.</h2></center></div>
							<?php
							}
						else
							echo "not send";
										?>